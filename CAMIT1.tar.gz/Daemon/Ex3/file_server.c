#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>

#define PORT 12456
#define BUFFER_SIZE 1024

int main() {
    int server_fd, new_socket;
    struct sockaddr_in address;
    int addrlen = sizeof(address);
    char buffer[BUFFER_SIZE] = {0};
    FILE *file;
    int read_bytes;

    system("touch /tmp/server_msg.txt");

    if (daemon(0, 0) == -1) {
        perror("Failed to daemonize");
        exit(EXIT_FAILURE);
    }

    // Create socket file descriptor
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("Socket failed");
        exit(EXIT_FAILURE);
    }

    // Set up the address structure




    // Bind the socket to the specified port




    // Start listening for connections





    printf("Daemon server started, waiting for connections...\n");

    while (1) {
        // Accept a connection





        // Open the file for reading
        file = fopen("/tmp/server_msg.txt", "r");
        if (file == NULL) {
            perror("File open failed");
            close(new_socket);
            printf("Server closed.\n");
            exit(0);
        }

        // Send file contents to the client





        fclose(file);
        close(new_socket);
        printf("File sent to client\n");
    }

    return 0;
}

