#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
    pid_t pid = fork();

    if (pid > 0) {
        printf("Parent starts (PID:%d)\n",getpid());
        for (;;) {}
    } else if (pid == 0) {
        printf("Child starts (PID:%d)\n",getpid());
        printf("Child ends (PID:%d)\n",getpid());
        exit(0);
    }
}
