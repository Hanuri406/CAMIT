#include <stdio.h>
#include <syslog.h>
#include <unistd.h>

int main() {
    // Open syslog and log the PID and include facility LOG_USER
    openlog("MyProgram", LOG_PID | LOG_CONS, LOG_USER);

    // Log an informational message
    syslog(LOG_INFO, "This is an informational message from MyProgram");

    // Log an error message
    syslog(LOG_ERR, "This is an error message");

    // Close the log
    closelog();

    return 0;
}

