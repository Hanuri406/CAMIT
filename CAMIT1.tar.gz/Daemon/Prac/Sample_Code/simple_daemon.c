#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void main() {
    if (daemon(0, 0) == -1) {
        perror("Failed to create daemon");
        exit(EXIT_FAILURE);
    }

    // Daemon process logic: Running in the background
    while (1) {
        sleep(10);
    }
}
