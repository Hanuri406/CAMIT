#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

void main() {
  pid_t pid;
  int status;

  pid = fork();

  if (pid == 0) {
    printf("Child process starting...\n");
    if (execl("./child", "child", NULL) == -1)
      perror("execl failed");
  } else {
    printf("(Parent) Waiting for Child\n");
    wait(&status);  

    if (WIFEXITED(status)) {
      printf("(Parent) Child exited normally\n");
    }
    printf("(Parent) The end of Parent\n");
  }
}

