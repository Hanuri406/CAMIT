import socket

# Create a TCP socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Bind the socket to localhost and a specific port
server_socket.bind(('localhost', 12345))

# Set a short timeout for accepting connections (e.g., 5 seconds)
server_socket.settimeout(5)

# Start listening for incoming connections
server_socket.listen(1)
print("Server is listening on port 12345...")

try:
    # Accept a connection
    client_socket, client_address = server_socket.accept()
    
except socket.timeout:
        print("Socket operation timed out during connection or data reception!")

server_socket.close()
print("Server socket closed.")
