# my_module.py
def greet(name):
    return f"Hello, {name}!"

def add(a, b):
    return a + b
