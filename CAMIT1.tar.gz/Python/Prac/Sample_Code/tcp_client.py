import socket
import sys

# Check if the port argument is provided
if len(sys.argv) != 2:
    print(f"Usage: {sys.argv[0]} <port>")
    sys.exit(1)

# Get the port number from the command line argument
port = int(sys.argv[1])

# Create a TCP socket
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Send data to the packet server at the given port
server_address = ('localhost', port)
client_socket.connect(server_address)

# Send multiple messages
for i in range(100):
    message = f"{i}: Hello, TCP Server!"
    client_socket.sendall(message.encode())
    print(f"(Client) Sent message {i}")

    # Receive response from the server
    data = client_socket.recv(1024)
    print(f"(Client) Received from server: {data.decode()}")

# Close the socket
client_socket.close()

