students_scores = {}

while True:
    student_name = input("Name: ")

    if student_name == "End":
        break

    score = int(input(f"Score:"))

    students_scores[student_name] = score

for student, score in students_scores.items():
    print(f"{student}: {score}")

