def factorial(n):
    result = 1
    for i in range(n):
        result *= (i+1)
    return result

for i in range(2,6):
     print(str(i)+"!:", factorial(i))
