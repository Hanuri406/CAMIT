file = open("zen.txt", "r")
line = file.readline()
while line:
    print(line)
    line = file.readline()
