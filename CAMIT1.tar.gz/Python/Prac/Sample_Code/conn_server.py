import socket

# Set up the server socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind(('localhost', 12345))
server_socket.listen()

print("Server is waiting...")
# Accept a connection
connection, client_address = server_socket.accept()
print(f"Connection accepted from {client_address}")

# Close the client connection socket
connection.close()
print("Connection socket closed.")

input("Press Enter to close the server socket.")

# Close the listening server socket
server_socket.close()
print("Server socket closed.")

