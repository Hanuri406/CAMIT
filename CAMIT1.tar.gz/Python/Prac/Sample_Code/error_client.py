import socket

try:
    # Create a TCP socket
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    # Attempt to connect to the server
    client_socket.connect(('localhost', 54321))
    
except socket.error as e:
    print(f"Socket error occurred: {e}")

finally:
    client_socket.close()
    print("Client socket closed.")

