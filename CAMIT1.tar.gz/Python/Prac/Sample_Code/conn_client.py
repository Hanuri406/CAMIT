import socket

# Create a client socket
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Connect to the server
client_socket.connect(('localhost', 12345))
print("Connected to the server.")

# Close the client socket
client_socket.close()
print("Client socket closed.")

