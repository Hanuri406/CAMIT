import socket
import sys

html_content = """
<!DOCTYPE html>
<html>
<head></head>
<body><h1>Welcome to My Toy Server</h1></body>
</html>
"""

if len(sys.argv) != 2:
  print("Usage: python toy_server.py <HOST_IP>")
  sys.exit(1)

HOST_IP = sys.argv[1]
port = 8000

# Create a socket object using TCP (SOCK_STREAM)


# Bind the socket to the specified host and port


# Enable the server to accept connections (make it a listening socket)



# Wait for a client connection



# Receive the request from the client




# Prepare the HTTP response
response = f"HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n{html_content}"

# Send the HTTP response to the client


# Close the connection
client_connection.close()

server_socket.close()
