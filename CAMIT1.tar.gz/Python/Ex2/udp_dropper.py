import socket
import random

# Create two UDP sockets: one for receiving from the client, one for forwarding to the server


# Bind the dropper to a specific port (it will act as a middleman)


# Server address (the real server the packets will eventually reach)


print("Packet dropper is running and simulating packet loss...")

while True:
    # Receive data from the client
    

    # Simulate packet loss by randomly dropping packets



    
    # Forward the packet to the actual server




