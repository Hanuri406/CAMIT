import csv

# Open the CSV file for reading
with open('example.csv', 'r') as file:
    csv_reader = csv.DictReader(file)
    
    # Iterate over the rows and print each one as a dictionary
    for row in csv_reader:
        print(row)

