#!/bin/bash

counter=1

for file in *; do
    if [ -f "$file" ]; then
        echo "$counter. $file"
        counter=$((counter + 1))
    fi
done
