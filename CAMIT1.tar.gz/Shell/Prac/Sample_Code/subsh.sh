#!/bin/bash

echo "Sub Shell PID: $$"
echo "MyX = $MyX"

