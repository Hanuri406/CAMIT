#!/bin/bash

file=$1

if [ ! -e "$file" ]; then
    echo "File does not exist"
    exit 0
fi

if [ -f "$file" ]; then
    echo "$file is a regular file"
    if [ -x "$file" ]; then
        echo "$file is executable"
    fi
fi

if [ -d "$file" ]; then
    echo "$file is a directory"
fi



