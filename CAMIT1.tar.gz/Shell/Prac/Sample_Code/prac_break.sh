#!/bin/bash

for num in {1..50}; do
    if [ $num -gt 10 ]; then
        break
    fi
    if [ $((num % 2)) -eq 1 ]; then
        continue
    fi
    echo "Number: $num"
done
