#!/bin/bash

TARGET_DIR="./Target_Program"
PROGRAM_NAME="counting"

# Monitor loop
while true; do










done
