#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int read_cmd(void) {
    int cmd_num;
    printf("1: ls, 2: pwd, 3: date. 4: exit\n");
    printf("Enter a command number : ");
    scanf("%d", &cmd_num);
    return cmd_num;
}

void exec_cmd(int cmd_num) {
    pid_t pid;
    int status;

    pid = fork();
    if (pid == 0) { // Child process













    } else if (pid < 0) {
        perror("fork failed");
        exit(0);
    } else {

    }
}

void main() {
    int cmd_num;

    printf("mini shell starts!\n");

    for (;;) {
        cmd_num = read_cmd();

        if (cmd_num == 4) {
            break;
        }
        exec_cmd(cmd_num);
    }
    printf("mini shell finished...\n");
}

