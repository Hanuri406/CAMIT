#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>

int main() {
    pid_t ret;
    ret = fork();
    if (ret < 0) {
        printf("Fork failed\n");
    } else if (ret == 0) { // child process
        execlp("/bin/ls","ls",NULL);
        printf("This code can't be executed\n");
    } else { // parent process
        sleep(1);
        printf("(Parent) PID = %d\n",getpid());
    }
}

