#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>

int main() {
    pid_t ret;
    ret = fork();
    if (ret < 0) {
        printf("Fork failed\n");
    } else if (ret == 0) {
        printf("(Child) Return value = %d\n",ret);
        printf("(Child) PID = %d\n",getpid());
    } else { // if (ret > 0)
        printf("(Parent) Return value = %d\n",ret);
        printf("(Parent) PID = %d\n",getpid());
    }
    printf("For both processes (%d)\n",getpid());
}

