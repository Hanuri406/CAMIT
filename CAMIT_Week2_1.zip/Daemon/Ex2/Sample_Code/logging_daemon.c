#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <syslog.h>
#include <string.h>

void log_file_content() {
    char file_content[1024] = {0};
    system("touch /tmp/input.txt");

    // Daemon loop
    while (1) {
        FILE *file = fopen("/tmp/input.txt", "r");
        if (file) {
            syslog(LOG_INFO, "/tmp/input.txt:");
            while (fgets(file_content, 1024, file) != NULL) {
                syslog(LOG_INFO, "%s", file_content);
            }
            fclose(file);
        } else {
            syslog(LOG_ERR, "Logging Daemon finished.");
            exit(0);
        }

        sleep(5);
    }
}

void main() {
    if (daemon(0, 0) == -1) {
        perror("daemon");
        exit(EXIT_FAILURE);
    }

    openlog("FileLoggerDaemon", LOG_PID, LOG_DAEMON);
    syslog(LOG_INFO, "Logging Daemon started.");

    log_file_content();

    closelog();
}
