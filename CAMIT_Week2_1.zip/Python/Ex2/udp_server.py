import socket

# Create a UDP socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Bind the socket to an IP address and port
server_address = ('localhost', 12345)
server_socket.bind(server_address)

print("UDP server is up and running...")

expected_number = 0
missed_packets = 0

while True:
    # Receive data from the client
    try:
        data, client_address = server_socket.recvfrom(1024)
        message = data.decode()

        # Extract the client number to track missing packets
        client_number = int(message.split(":")[0])
        print(f"(Server) Received message {client_number} from {client_address}")

        # If the client number is not in order, packets were missed
        if client_number != expected_number:
            missed_packets += client_number - expected_number
            print(f"(Server) Missed {missed_packets} packet(s)")

        expected_number = client_number + 1
        if client_number > 90:
            print(f"(Server) Server terminates...")
            server_socket.close()
            break

    except Exception as e:
        print(f"(Server) Error occurred: {e}")

