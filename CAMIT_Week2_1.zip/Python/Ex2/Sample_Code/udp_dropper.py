import socket
import random

# Create two UDP sockets: one for receiving from the client, one for forwarding to the server
dropper_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Bind the dropper to a specific port (it will act as a middleman)
dropper_socket.bind(('localhost', 55555))

# Server address (the real server the packets will eventually reach)
server_address = ('localhost', 12345)

print("Packet dropper is running and simulating packet loss...")

while True:
    # Receive data from the client
    data, client_address = dropper_socket.recvfrom(1024)
    
    # Simulate packet loss by randomly dropping packets
    if random.random() > 0.8:  # Drop 20% of packets (adjust as needed)
        print(f"Dropped packet from {client_address}: {data.decode()}")
        continue
    
    # Forward the packet to the actual server
    dropper_socket.sendto(data, server_address)
    print(f"Forwarded packet from {client_address} to the server")

