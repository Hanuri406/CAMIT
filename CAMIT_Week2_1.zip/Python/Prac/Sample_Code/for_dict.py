dict = {"A":10, "B":20, "C":30}

for key in dict:
    print(key, dict[key])
print("======")
for key, value in dict.items():
    print(key, value)

