import socket

# Create a TCP socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Bind the socket to an IP address and port
server_address = ('localhost', 12345)
server_socket.bind(server_address)

# Listen for incoming connections
server_socket.listen(1)
print("TCP server is up and running...")

expected_number = 0
missed_packets = 0

# Accept a connection from a client
connection, client_address = server_socket.accept()
print(f"Connection established with {client_address}")

while True:
    # Receive data from the client
    data = connection.recv(1024)
    if data:
        message = data.decode()
        client_number = int(message.split(":")[0])
        print(f"(Server) Received message {client_number}")
        return_msg = f"Message received {client_number}".encode()
        connection.sendall(return_msg)
    else:
        break

connection.close()
