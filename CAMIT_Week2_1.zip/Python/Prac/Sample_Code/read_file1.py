file = open("zen.txt", "r")
line = file.readline()
while line:
    print(line.strip())
    line = file.readline()
