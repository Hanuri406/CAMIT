#!/bin/bash

ls -l zen.txt
wc -c zen.txt
