#!/bin/bash

counter=$1
msg=$2

while [ $counter -gt 0 ]; do
    echo $counter, $msg
    counter=$(($counter - 1))
done
