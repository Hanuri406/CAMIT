#!/bin/bash

output="Sample Code"
echo $output
