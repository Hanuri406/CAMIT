#!/bin/bash

# Assign arguments to variables
SOURCE_DIR=$1
DEST_DIR=$2

if [ "$#" -ne 2 ]; then
    echo "Usage: $0 SOURCE BACKUP"
    exit 1
fi

# Get the current date
DATE=$(date +%Y%m%d)
BACKUP_FILE="backup_$DATE.tar.gz"

# Check if a backup with the same name already exists
if [ -f "$DEST_DIR/$BACKUP_FILE" ]; then
    # If it exists, create a new name with an incrementing number
    COUNT=1
    while [ -f "$DEST_DIR/backup_${DATE}_$COUNT.tar.gz" ]; do
        COUNT=$((COUNT + 1))
    done
    BACKUP_FILE="backup_${DATE}_$COUNT.tar.gz"
fi

# Create the backup file
tar -czf "$DEST_DIR/$BACKUP_FILE" "$SOURCE_DIR"

# Print completion message
echo "Backup completed: $DEST_DIR/$BACKUP_FILE"

