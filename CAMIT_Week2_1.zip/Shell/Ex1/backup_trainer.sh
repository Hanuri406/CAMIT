#!/bin/bash

# Assign arguments to variables
SOURCE_DIR=$1
DEST_DIR=$2

if [ "$#" -ne 2 ]; then
    echo "Usage: $0 SOURCE BACKUP"
    exit 1
fi

# Get the current date
DATE=$(date +%Y%m%d)
BACKUP_FILE="backup_$DATE.tar.gz"















# Print completion message
echo "Backup completed: $DEST_DIR/$BACKUP_FILE"

