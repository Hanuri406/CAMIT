// script.js
document.addEventListener('DOMContentLoaded', function() {
    const addTaskButton = document.getElementById('add-task-btn');
    const taskInput = document.getElementById('new-task');
    const taskList = document.getElementById('task-list');

    // Function to add a new task
    function addTask() {
        const taskText = taskInput.value.trim();
        if (taskText === '') {
            alert('Please enter a task.');
            return;
        }

        // Create a new list item
        const newTaskItem = document.createElement('li');
        newTaskItem.textContent = taskText;

        // Create complete button
        const completeButton = document.createElement('button');
        completeButton.textContent = 'Complete';
        completeButton.classList.add('complete-btn');
        completeButton.addEventListener('click', () => {
            newTaskItem.classList.toggle('completed');
        });

        // Create delete button
        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete';
        deleteButton.classList.add('delete-btn');
        deleteButton.addEventListener('click', () => {
            taskList.removeChild(newTaskItem);
        });

        // Append buttons to the task item
        newTaskItem.appendChild(completeButton);
        newTaskItem.appendChild(deleteButton);

        // Add the new task to the task list
        taskList.appendChild(newTaskItem);

        // Clear the input field
        taskInput.value = '';
    }

    // Add event listener to the button to add tasks
    addTaskButton.addEventListener('click', addTask);

    // Add task when pressing Enter in the input field
    taskInput.addEventListener('keypress', function(event) {
        if (event.key === 'Enter') {
            addTask();
        }
    });
});

