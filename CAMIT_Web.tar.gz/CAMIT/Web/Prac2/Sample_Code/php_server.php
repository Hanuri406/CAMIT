<?php
// Check if the message is received via POST request
if (isset($_POST['message'])) {
    $message = htmlspecialchars($_POST['message']); // Sanitize the input to prevent XSS attacks
    echo "PHP received: " . $message; // Respond back with the message received
} else {
    echo "No message received.";
}
?>

