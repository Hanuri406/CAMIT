const puzzleBoard = document.getElementById('puzzle-grid');
const shuffleButton = document.getElementById('shuffle-button');
const moveCounterElement = document.getElementById('move-counter');
const container = document.getElementById('container');

let moveCount = 0; 

// Initialize the puzzle tiles
let tiles = [0, 1, 2, 3, 4, 5, 6, 7, 8]
tiles[tiles.length - 1] = ''; 

// Print the current board
function printBoard() {
    // Clear the puzzle board
    puzzleBoard.innerHTML = '';

    // Loop through each tile in the tiles array
    for (let index = 0; index < tiles.length; index++) {
        // Create a new div element for each tile
        const tileDiv = document.createElement('div');
        // Add a class to the tile for styling
        tileDiv.className = 'puzzle-tile';
        // Set the text of the tile
        tileDiv.textContent = tiles[index];

        // If the tile is empty, add a special class
        if (tiles[index] === '') {
            tileDiv.className += ' empty-tile';
        } else {
            // If the tile is not empty, make it clickable to move
            tileDiv.onclick = function() {
                moveTile(index);
            };
        }

        // Add the tile to the puzzle board
        puzzleBoard.appendChild(tileDiv);
    }
}

// Function to check if the clicked tile can move
function moveTile(index) {
    const emptyIndex = tiles.indexOf('');
    const validMoves = [emptyIndex - 1, emptyIndex + 1, emptyIndex - 3, emptyIndex + 3]; // Left, right, up, down

    if (validMoves.includes(index)) {
        // Swap the empty tile and the clicked tile
        [tiles[emptyIndex], tiles[index]] = [tiles[index], tiles[emptyIndex]];

        // Increment the move count and update the display
        moveCount++;
        moveCounterElement.textContent = moveCount;

        printBoard();

        if (checkWin()) {
            showWinningScreen();
        }
    }
}

// Function to shuffle the tiles
function shuffleTiles() {
    moveCount = 0; // Reset the move count
    moveCounterElement.textContent = moveCount;
    
    moves = 30;
    for (let i = 0; i < moves; i++) {
        makeRandomMove();
    }

    printBoard();
}

// Function to make a random valid move
function makeRandomMove() {
    const emptyIndex = tiles.indexOf('');
    const validMoves = getValidMoves(emptyIndex);
    const randomMove = validMoves[Math.floor(Math.random() * validMoves.length)];
    
    // Swap the empty tile with a valid neighboring tile
    [tiles[emptyIndex], tiles[randomMove]] = [tiles[randomMove], tiles[emptyIndex]];
}

// Function to get valid neighboring moves
function getValidMoves(emptyIndex) {
    const gridWidth = Math.sqrt(tiles.length);
    const moves = [];

    // Check if we can move up, down, left, or right
    if (emptyIndex - gridWidth >= 0) moves.push(emptyIndex - gridWidth); // Up
    if (emptyIndex + gridWidth < tiles.length) moves.push(emptyIndex + gridWidth); // Down
    if (emptyIndex % gridWidth !== 0) moves.push(emptyIndex - 1); // Left
    if (emptyIndex % gridWidth !== gridWidth - 1) moves.push(emptyIndex + 1); // Right

    return moves;
}


// Function to check if the puzzle is solved
function checkWin() {
  for (let i = 0; i < tiles.length - 1; i++) {
    if (tiles[i] !== i) {
      return false;
    }
  }
  return true;
}

// Function to display the winning screen
function showWinningScreen() {
    container.innerHTML = `
        <div class="winning-screen">
            <h1>Congratulations!</h1>
            <p>You solved the puzzle in ${moveCount} moves!</p>
        </div>
    `;
}

// Event listener to shuffle the puzzle when the button is clicked
shuffleButton.addEventListener('click', shuffleTiles);

printBoard();

